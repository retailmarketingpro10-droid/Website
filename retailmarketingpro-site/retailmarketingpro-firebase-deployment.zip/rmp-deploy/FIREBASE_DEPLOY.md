# Firebase Hosting Deployment Guide

## Current Status
✅ Firebase CLI installed (v14.26.0)
✅ React app built and ready (dist/ folder created)
✅ firebase.json configured for SPA routing
✅ .firebaserc configured with project ID: website-c6d95

## Next Steps - Manual Login & Deployment

### Option 1: Firebase CLI Web Login (Recommended for Local Machine)
Run this command on your local machine (not in Codespace):
```bash
firebase login
```
This will open your browser for Google authentication.

### Option 2: Use Firebase Service Account (For CI/CD)
If deploying from CI/CD, use a service account key instead of interactive login.

## Once Authenticated - Deploy

After authentication, run:
```bash
firebase deploy --project website-c6d95
```

This will:
1. Upload the dist/ folder to Firebase Hosting
2. Configure the SPA rewrite rules
3. Provide your live URL (typically: https://website-c6d95.web.app)

## Verify Deployment
After deployment completes, visit:
- https://website-c6d95.web.app (live URL)
- https://website-c6d95.firebaseapp.com (alternate)

## Contact Form Testing
Once live:
1. Navigate to the contact form section
2. Submit a test message
3. Check Firebase Console > Firestore > "contacts" collection for submissions

## Custom Domain Setup
1. Go to Firebase Console > Hosting
2. Click "Add custom domain"
3. Follow DNS configuration steps with your domain registrar
4. Typical TTL: 24-48 hours for propagation

## Firestore Setup (Required for Contact Form)
If not already created, you must enable Firestore:
1. Go to Firebase Console > Firestore Database
2. Create database (us-central1 region recommended)
3. Set Security Rules:
```
rules_version = '3';
service cloud.firestore {
  match /databases/{database}/documents {
    match /contacts/{document=**} {
      allow read, write: if request.time < timestamp.date(2026, 1, 1);
    }
  }
}
```
4. Publish rules

This allows contact form submissions for testing. For production, implement proper authentication.
