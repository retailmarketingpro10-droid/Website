#!/bin/bash

# Firebase Hosting Deployment Script for RetailMarketingPro

PROJECT_ID="website-c6d95"
echo "🚀 Firebase Hosting Deployment Script"
echo "Project ID: $PROJECT_ID"
echo ""

# Step 1: Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "❌ Firebase CLI not found. Installing..."
    npm install -g firebase-tools
fi

# Step 2: Check if already authenticated
if [ ! -f ~/.firebase/credentials.json ]; then
    echo "⚠️  You need to authenticate with Firebase first."
    echo ""
    echo "Run this command on your local machine:"
    echo "   firebase login"
    echo ""
    echo "This will open your browser to authenticate with Google."
    echo ""
    exit 1
fi

# Step 3: Verify dist folder exists
if [ ! -d "react-app/dist" ]; then
    echo "📦 Building React app..."
    cd react-app
    npm run build
    cd ..
fi

# Step 4: Deploy to Firebase
echo "📤 Deploying to Firebase Hosting..."
firebase deploy --project $PROJECT_ID

# Step 5: Success message
echo ""
echo "✅ Deployment complete!"
echo ""
echo "Your site is live at:"
echo "  🌐 https://$PROJECT_ID.web.app"
echo "  🌐 https://$PROJECT_ID.firebaseapp.com"
echo ""
echo "To add a custom domain:"
echo "  1. Go to Firebase Console > Hosting"
echo "  2. Click 'Add custom domain'"
echo "  3. Follow DNS configuration steps"
